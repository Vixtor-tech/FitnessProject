# fitnessProjet (Administración de Gimnasio)

Sistema de gestión para gimnasios de alto rendimiento: administración de clientes con carnet de socio, catálogo completo de clases deportivas y control de reservas activas/vencidas.
Desarrollado con **Spring Boot**, **Thymeleaf** y **Spring Data JPA** (H2 en memoria), con una arquitectura limpia en tres capas (controlador → servicio → repositorio) y doble interfaz: **web moderna HTML/CSS (tema negro y naranja deportivo)** y **API REST JSON**.

## Arrancar el Proyecto

Desde la terminal de PowerShell en VS Code:

```powershell

.\mvnw.cmd spring-boot:run
```

Abrir en el navegador:
`http://localhost:8081`

- **Base de datos H2 en memoria**: Se inicializa y puebla automáticamente al arrancar (6 clases preconfiguradas, 3 clientes, 1 reserva vencida para pruebas). Consola disponible en `http://localhost:8081/h2-console`.
- **Ejecutar Pruebas**: `.\mvnw.cmd test`

Informe del proyecto GymProjet

1. Introducción
   GymProjet es una aplicación web creada para administrar un gimnasio. Su objetivo es organizar la información de los clientes, las clases y las reservas en un solo lugar.
2. Herramientas utilizadas

- Java: lenguaje utilizado para programar.
- Spring Boot: permite ejecutar la aplicación web.
- Maven: ayuda a organizar y ejecutar el proyecto.
- HTML y Thymeleaf: permiten crear las páginas y mostrar la información.
- CSS: se utiliza para mejorar el diseño.
- H2: base de datos donde se guarda la información durante la ejecución.

3. ¿Cómo funciona el código?
   El proyecto está dividido en varias carpetas para mantener el código organizado:

- Modelo: representa los datos de clientes, clases y reservas.
- Controlador: recibe las solicitudes del usuario.
- Servicio: realiza los procesos y las comprobaciones.
- Repositorio: permite consultar, guardar, modificar y eliminar información.
- Templates: contiene las páginas que se muestran en el navegador.
- Static: contiene los estilos y las imágenes de la página.
  Estas partes trabajan juntas para que el usuario pueda utilizar las funciones del gimnasio.

4. Ejecución del proyecto
   El proyecto se ejecuta desde la terminal de Visual Studio Code con el siguiente comando:
   .\mvnw.cmd spring-boot:run

Después, se abre el navegador en http://localhost:8081 para acceder a la aplicación. 5. Conclusión
Con GymProjet aprendí a organizar un proyecto en Java, crear páginas web y conectar diferentes partes de una aplicación. También comprendí cómo se maneja la información mediante una base de datos y cómo Spring Boot ayuda a poner en funcionamiento el sistema.

## Estructura (com.example.gymprojet)

    modelo/        Cliente · Carnet · Clase · Categoria · Entrenador · Reserva
    repositorio/   Un repositorio Spring Data JPA por entidad
    servicio/      ClienteService(Impl) · ClaseService(Jpa) · ReservaService
                   DashboardService(Impl) · DemoService(Impl)
                   ReglaNegocioException · NoEncontradoException (Reglas de negocio)
    controlador/   ClienteController · ClaseController · ReservaController · InicioController
                   ClienteRestController · ClaseRestController
                   ManejadorDeErrores (HTML) · GlobalExceptionHandler (REST JSON)
                   ClienteDemoController · ParametrosDemoController (Demos de parámetros)
      dto/         ClienteDTO · ClienteEntrada · ClaseDTO · ClaseEntrada · ResumenCategoria · DashboardDTO
    config/        WebConfig · DatosIniciales (poblado de datos de prueba)

## Rutas Web

| Método | Ruta                                            | Descripción                            |
| :----- | :---------------------------------------------- | :------------------------------------- |
| GET    | `/`                                             | Dashboard principal                    |
| GET    | `/clientes` (`?buscar=`)                        | Catálogo y búsqueda de clientes        |
| GET    | `/clientes/nuevo` · POST `/clientes`            | Formulario y registro                  |
| GET    | `/clientes/{id}`                                | Ficha con carnet e historial           |
| GET    | `/clientes/{id}/editar` · POST `/clientes/{id}` | Edición de cliente                     |
| POST   | `/clientes/{id}/borrar`                         | Eliminar cliente                       |
| GET    | `/clases` (`?buscar=`)                          | Catálogo de clases                     |
| GET    | `/clases/nueva` · POST `/clases`                | Formulario y creación                  |
| GET    | `/clases/{id}`                                  | Ficha de clase y reserva directa       |
| GET    | `/clases/{id}/editar` · POST `/clases/{id}`     | Edición de clase                       |
| POST   | `/clases/{id}/borrar`                           | Eliminar clase                         |
| GET    | `/reservas`                                     | Control de reservas activas y vencidas |
| POST   | `/reservas/reservar`                            | Crear reserva (`idClase`, `idCliente`) |
| POST   | `/reservas/{id}/finalizar`                      | Finalizar reserva                      |

## API REST

| Método | Ruta                                         | Respuesta esperada                                        |
| :----- | :------------------------------------------- | :-------------------------------------------------------- |
| GET    | `/api/clientes` · `/api/clases` (`?buscar=`) | 200 OK + lista JSON                                       |
| GET    | `/api/clientes/{id}` · `/api/clases/{id}`    | 200 OK / 404 No encontrado                                |
| POST   | `/api/clientes` · `/api/clases`              | 201 Created + `Location` / 400 Bad Request / 409 Conflict |
| PUT    | `/api/clientes/{id}` · `/api/clases/{id}`    | 200 OK / 404 / 409                                        |
| DELETE | `/api/clientes/{id}` · `/api/clases/{id}`    | 204 No Content / 404 / 409                                |

Demos adicionales (`@RequestParam`, `@PathVariable`): `/api/demo/...`

```bash
curl -i http://localhost:8081/api/clases
curl -i http://localhost:8081/api/clases/999
curl -i -X POST http://localhost:8081/api/clases -H "Content-Type: application/json" \
  -d "{\"nombre\":\"Boxeo\",\"codigo\":\"BX-401\",\"duracionMinutos\":60,\"categoria\":\"Cardio\",\"entrenadores\":\"Pedro Ruiz\"}"
curl -i -X POST http://localhost:8081/api/clientes -H "Content-Type: application/json" \
  -d "{\"nombre\":\"Pedro Sánchez\",\"email\":\"pedro@gym.com\"}"
```

## Reglas de Negocio Implementadas

1. **Unicidad de código**: El código de una clase es único (`ClaseServiceJpa`).
2. **Disponibilidad y reserva única**: Una clase no disponible no puede reservarse, y un cliente no puede duplicar reservas activas en la misma clase (`ReservaService`).
3. **Límite de reservas vivas**: Máximo 3 reservas activas simultáneas por socio (`ReservaService`).
4. **Integridad referencial en borrado**: Una clase o cliente con historial de reservas no puede eliminarse (`ClaseServiceJpa` y `ClienteServiceImpl`).
5. **Caducidad**: Una reserva activa con más de 15 días se considera vencida (`Reserva.estaVencida`).
6. **Unicidad de email**: Cada cliente debe poseer un correo electrónico único.
