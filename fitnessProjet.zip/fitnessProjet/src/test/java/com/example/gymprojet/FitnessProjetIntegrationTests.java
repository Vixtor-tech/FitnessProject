package com.example.gymprojet;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
class FitnessProjetIntegrationTests {

    @Autowired
    private WebApplicationContext context;

    private MockMvc mvc;

    @BeforeEach
    void setup() {
        this.mvc = MockMvcBuilders.webAppContextSetup(context).build();
    }

    @Test
    void testInicioWeb() throws Exception {
        mvc.perform(get("/"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("fitnessProjet")))
                .andExpect(content().string(containsString("Panel General")));
    }

    @Test
    void testCatalogoClases() throws Exception {
        mvc.perform(get("/clases"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("Catálogo de Clases")));
    }

    @Test
    void testListaClientes() throws Exception {
        mvc.perform(get("/clientes"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("Catálogo de Clientes")));
    }

    @Test
    void testReservas() throws Exception {
        mvc.perform(get("/reservas"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("Gestión de Reservas")));
    }

    @Test
    void testDemoSaludo() throws Exception {
        mvc.perform(get("/api/demo/saludo"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("Bienvenido a fitnessProjet.")));
    }

    @Test
    void testApiClases() throws Exception {
        mvc.perform(get("/api/clases"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray());
    }

    @Test
    void testApiClientesCrearYValidar() throws Exception {
        // Validation error: invalid email
        mvc.perform(post("/api/clientes")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"nombre\":\"Juan\",\"email\":\"email-invalido\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.error").exists());

        // Valid client creation
        mvc.perform(post("/api/clientes")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"nombre\":\"Nuevo Atleta\",\"email\":\"nuevo.atleta@fitness.com\"}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.nombre").value("Nuevo Atleta"));

        // Conflict: Duplicate email
        mvc.perform(post("/api/clientes")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"nombre\":\"Otro Atleta\",\"email\":\"nuevo.atleta@fitness.com\"}"))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.error").exists());
    }
}
