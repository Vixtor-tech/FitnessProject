package com.example.gymprojet.controlador.dto;

import com.example.gymprojet.modelo.Cliente;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

public record ClienteEntrada(
        @NotBlank(message = "El nombre es obligatorio")
        String nombre,

        @NotBlank(message = "El email es obligatorio")
        @Email(message = "Email con formato no válido")
        String email) {
    public Cliente aCliente() {
        return new Cliente(nombre, email);
    }
}
