package com.example.gymprojet.servicio;

import java.util.List;

public interface DemoService {
    String generarSaludo(String nombre);
    String calcularCuota(String membresia);
    String filtrarOListar(String q);
    String generarRutina(String ejercicio, int series);
    List<String> obtenerClientesDemo();
    String obtenerClienteDemoPorIndice(int indice);
}
