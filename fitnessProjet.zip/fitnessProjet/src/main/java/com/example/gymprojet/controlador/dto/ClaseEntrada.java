package com.example.gymprojet.controlador.dto;

import com.example.gymprojet.modelo.Clase;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

public record ClaseEntrada(
        @NotBlank(message = "El nombre es obligatorio")
        String nombre,

        @NotBlank(message = "El código es obligatorio")
        @Pattern(regexp = "[A-Za-z0-9\\-]{3,20}", message = "El código debe tener 3-20 letras, números o guiones")
        String codigo,

        @NotNull(message = "La duración es obligatoria")
        @Min(value = 15, message = "La duración mínima es de 15 minutos")
        @Max(value = 300, message = "La duración no puede superar los 300 minutos")
        Integer duracionMinutos,

        Boolean disponible,
        String categoria,
        String entrenadores) {
    public Clase aClase() {
        Clase clase = new Clase(nombre, codigo, duracionMinutos);
        clase.setDisponible(disponible == null || disponible);
        return clase;
    }
}
