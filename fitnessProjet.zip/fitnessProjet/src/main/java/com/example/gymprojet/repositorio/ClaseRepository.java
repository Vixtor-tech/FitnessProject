package com.example.gymprojet.repositorio;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.example.gymprojet.controlador.dto.ResumenCategoria;
import com.example.gymprojet.modelo.Clase;

public interface ClaseRepository extends JpaRepository<Clase, Long> {
    Optional<Clase> findByCodigo(String codigo);
    boolean existsByCodigo(String codigo);

    List<Clase> findByNombreContainingIgnoreCase(String texto);
    List<Clase> findByCategoriaNombreIgnoreCase(String categoria);
    List<Clase> findByDisponibleTrueOrderByNombreAsc();
    List<Clase> findTop10ByOrderByIdDesc();

    @Query("""
        select distinct c from Clase c
        left join fetch c.categoria
        left join fetch c.entrenadores
        where c.id in (
            select c2.id from Clase c2
            left join c2.entrenadores e
            where lower(c2.nombre) like lower(concat('%', :texto, '%'))
               or lower(e.nombre) like lower(concat('%', :texto, '%')))
        order by c.nombre
    """)
    List<Clase> buscarPorNombreOEntrenador(@Param("texto") String texto);

    @Query("""
        select distinct c from Clase c
        left join fetch c.categoria
        left join fetch c.entrenadores
        order by c.nombre
    """)
    List<Clase> listarConTodo();

    @Query("""
        select new com.example.gymprojet.controlador.dto.ResumenCategoria(
            cat.nombre, count(c))
        from Clase c
        join c.categoria cat
        group by cat.nombre
        order by count(c) desc
    """)
    List<ResumenCategoria> contarPorCategoria();
}
