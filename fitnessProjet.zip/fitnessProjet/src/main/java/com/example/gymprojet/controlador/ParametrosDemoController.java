package com.example.gymprojet.controlador;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.gymprojet.servicio.DemoService;

@RestController
@RequestMapping("/api/demo")
public class ParametrosDemoController {

    private final DemoService demoService;

    public ParametrosDemoController(DemoService demoService) {
        this.demoService = demoService;
    }

    @GetMapping("/saludo")
    public String saludo(@RequestParam(value = "nombre", defaultValue = "Deportista") String nombre) {
        return demoService.generarSaludo(nombre);
    }

    @GetMapping("/cuota")
    public String cuota(@RequestParam String membresia) {
        return demoService.calcularCuota(membresia);
    }

    @GetMapping("/buscar")
    public String buscar(@RequestParam(required = false) String q) {
        return demoService.filtrarOListar(q);
    }

    @GetMapping("/rutina")
    public String rutina(
            @RequestParam String ejercicio,
            @RequestParam(defaultValue = "1") int series) {
        return demoService.generarRutina(ejercicio, series);
    }
}
