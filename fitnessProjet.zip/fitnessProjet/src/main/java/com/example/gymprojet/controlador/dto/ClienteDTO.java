package com.example.gymprojet.controlador.dto;

import com.example.gymprojet.modelo.Cliente;

public record ClienteDTO(
        Long id,
        String nombre,
        String email,
        String carnet) {
    public static ClienteDTO de(Cliente c) {
        return new ClienteDTO(
                c.getId(),
                c.getNombre(),
                c.getEmail(),
                c.getCarnet() == null ? null : c.getCarnet().getNumero());
    }
}
