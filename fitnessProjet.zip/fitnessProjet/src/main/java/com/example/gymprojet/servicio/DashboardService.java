package com.example.gymprojet.servicio;

import com.example.gymprojet.controlador.dto.DashboardDTO;

public interface DashboardService {
    DashboardDTO obtenerDashboard();
}
