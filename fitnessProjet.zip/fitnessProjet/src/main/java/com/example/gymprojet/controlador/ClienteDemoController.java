package com.example.gymprojet.controlador;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.gymprojet.servicio.DemoService;

@RestController
@RequestMapping("/api/demo/clientes")
public class ClienteDemoController {

    private final DemoService demoService;

    public ClienteDemoController(DemoService demoService) {
        this.demoService = demoService;
    }

    @GetMapping
    public List<String> clientes() {
        return demoService.obtenerClientesDemo();
    }

    @GetMapping("/{indice}")
    public String cliente(@PathVariable int indice) {
        return demoService.obtenerClienteDemoPorIndice(indice);
    }
}
