package com.example.gymprojet.servicio;

import java.time.LocalDate;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.gymprojet.modelo.Clase;
import com.example.gymprojet.modelo.Cliente;
import com.example.gymprojet.modelo.Reserva;
import com.example.gymprojet.repositorio.ClaseRepository;
import com.example.gymprojet.repositorio.ClienteRepository;
import com.example.gymprojet.repositorio.ReservaRepository;

@Service
@Transactional(readOnly = true)
public class ReservaService {
    public static final int MAXIMO_VIVAS = 3;

    private final ReservaRepository reservas;
    private final ClaseRepository clases;
    private final ClienteRepository clientes;

    public ReservaService(ReservaRepository reservas,
                          ClaseRepository clases,
                          ClienteRepository clientes) {
        this.reservas = reservas;
        this.clases = clases;
        this.clientes = clientes;
    }

    public List<Reserva> vivas() {
        return reservas.vivas();
    }

    public List<Reserva> vencidas() {
        return reservas.vencidas(LocalDate.now().minusDays(Reserva.DIAS_PLAZO));
    }

    public int contarVencidas() {
        return vencidas().size();
    }

    public List<Reserva> deCliente(Long idCliente) {
        Cliente cliente = clientes.findById(idCliente)
                .orElseThrow(() -> new NoEncontradoException("No existe el cliente " + idCliente));
        return reservas.historial(cliente);
    }

    @Transactional
    public Reserva reservar(Long idClase, Long idCliente) {
        if (idClase == null || idCliente == null) {
            throw new ReglaNegocioException("Debe seleccionar una clase y un cliente válidos");
        }
        Clase clase = clases.findById(idClase)
                .orElseThrow(() -> new NoEncontradoException("No existe la clase " + idClase));
        Cliente cliente = clientes.findById(idCliente)
                .orElseThrow(() -> new NoEncontradoException("No existe el cliente " + idCliente));

        if (!clase.isDisponible()) {
            throw new ReglaNegocioException("La clase «" + clase.getNombre() + "» no está disponible");
        }
        if (reservas.existsByClaseAndClienteAndFechaFinalizacionIsNull(clase, cliente)) {
            throw new ReglaNegocioException(
                    cliente.getNombre() + " ya tiene una reserva activa en «" + clase.getNombre() + "»");
        }

        if (reservas.countByClienteAndFechaFinalizacionIsNull(cliente) >= MAXIMO_VIVAS) {
            throw new ReglaNegocioException(
                    cliente.getNombre() + " ya tiene " + MAXIMO_VIVAS + " reservas activas");
        }

        return reservas.save(new Reserva(clase, cliente));
    }

    @Transactional
    public void finalizar(Long idReserva) {
        if (idReserva == null) {
            throw new ReglaNegocioException("Identificador de reserva no válido");
        }
        Reserva reserva = reservas.findById(idReserva)
                .orElseThrow(() -> new NoEncontradoException("No existe la reserva " + idReserva));
        if (!reserva.estaViva()) {
            throw new ReglaNegocioException("Esa reserva ya estaba finalizada");
        }
        reserva.setFechaFinalizacion(LocalDate.now());
    }
}
