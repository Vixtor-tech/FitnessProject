package com.example.gymprojet.repositorio;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.example.gymprojet.modelo.Cliente;

public interface ClienteRepository extends JpaRepository<Cliente, Long> {
    boolean existsByEmail(String email);

    Optional<Cliente> findByEmail(String email);

    @Query("""
           select distinct c from Cliente c
           left join fetch c.carnet
           left join fetch c.reservas
           order by c.nombre
           """)
    List<Cliente> listarConReservas();

    @Query("""
           select distinct c from Cliente c
           left join fetch c.carnet
           left join fetch c.reservas
           where lower(c.nombre) like lower(concat('%', :texto, '%'))
              or lower(c.email) like lower(concat('%', :texto, '%'))
           order by c.nombre
           """)
    List<Cliente> buscarConReservas(@Param("texto") String texto);
}
