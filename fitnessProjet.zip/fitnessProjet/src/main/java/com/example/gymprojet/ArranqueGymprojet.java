package com.example.gymprojet;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class ArranqueGymprojet implements CommandLineRunner {
    @Override
    public void run(String... args) {
        System.out.println("=== fitnessProjet listo ===");
    }
}
