package com.example.gymprojet.controlador;

import java.net.URI;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.gymprojet.controlador.dto.ClienteDTO;
import com.example.gymprojet.controlador.dto.ClienteEntrada;
import com.example.gymprojet.servicio.ClienteService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/clientes")
public class ClienteRestController {

    private final ClienteService servicio;

    public ClienteRestController(ClienteService servicio) {
        this.servicio = servicio;
    }

    @GetMapping
    public List<ClienteDTO> listar(@RequestParam(defaultValue = "") String buscar) {
        return servicio.buscarDTO(buscar);
    }

    @GetMapping("/{id}")
    public ClienteDTO ver(@PathVariable Long id) {
        return servicio.buscarPorIdDTO(id);
    }

    @PostMapping
    public ResponseEntity<ClienteDTO> crear(@Valid @RequestBody ClienteEntrada entrada) {
        ClienteDTO creado = servicio.crearDesdeEntrada(entrada);
        return ResponseEntity
                .created(URI.create("/api/clientes/" + creado.id()))
                .body(creado);
    }

    @PutMapping("/{id}")
    public ClienteDTO actualizar(@PathVariable Long id, @Valid @RequestBody ClienteEntrada entrada) {
        return servicio.actualizarDesdeEntrada(id, entrada);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void borrar(@PathVariable Long id) {
        servicio.borrar(id);
    }
}
