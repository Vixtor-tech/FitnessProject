package com.example.gymprojet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GymprojetApplication {
	public static void main(String[] args) {
		SpringApplication.run(GymprojetApplication.class, args);
	}
}
