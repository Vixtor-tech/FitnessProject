package com.example.gymprojet.controlador.dto;

public record ResumenCategoria(String categoria, long total) {
}
