package com.example.gymprojet.controlador;

import org.springframework.http.HttpStatus;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.example.gymprojet.servicio.NoEncontradoException;

@ControllerAdvice
public class ManejadorDeErrores {
    @ExceptionHandler(NoEncontradoException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public String noEncontrado(NoEncontradoException e, Model modelo) {
        modelo.addAttribute("mensaje", e.getMessage());
        return "error/404";
    }
}
