package com.example.gymprojet.modelo;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import jakarta.persistence.*;

@Entity
@Table(name = "reservas")
public class Reserva {
    public static final int DIAS_PLAZO = 15;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "clase_id")
    private Clase clase;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "cliente_id")
    private Cliente cliente;

    @Column(name = "fecha_reserva", nullable = false)
    private LocalDate fechaReserva = LocalDate.now();

    @Column(name = "fecha_finalizacion")
    private LocalDate fechaFinalizacion;

    public Reserva() {
    }

    public Reserva(Clase clase, Cliente cliente) {
        this.clase = clase;
        this.cliente = cliente;
    }

    public boolean estaViva() {
        return fechaFinalizacion == null;
    }

    public boolean estaVencida() {
        return estaViva() && diasFuera() > DIAS_PLAZO;
    }

    public long diasFuera() {
        if (fechaReserva == null) {
            return 0;
        }
        return ChronoUnit.DAYS.between(fechaReserva, LocalDate.now());
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Clase getClase() {
        return clase;
    }

    public void setClase(Clase clase) {
        this.clase = clase;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public LocalDate getFechaReserva() {
        return fechaReserva;
    }

    public void setFechaReserva(LocalDate fechaReserva) {
        this.fechaReserva = fechaReserva;
    }

    public LocalDate getFechaFinalizacion() {
        return fechaFinalizacion;
    }

    public void setFechaFinalizacion(LocalDate fechaFinalizacion) {
        this.fechaFinalizacion = fechaFinalizacion;
    }
}
