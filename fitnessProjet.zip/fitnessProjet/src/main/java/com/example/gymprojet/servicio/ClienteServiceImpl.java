package com.example.gymprojet.servicio;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.gymprojet.controlador.dto.ClienteDTO;
import com.example.gymprojet.controlador.dto.ClienteEntrada;
import com.example.gymprojet.modelo.Carnet;
import com.example.gymprojet.modelo.Cliente;
import com.example.gymprojet.modelo.Reserva;
import com.example.gymprojet.repositorio.ClienteRepository;
import com.example.gymprojet.repositorio.ReservaRepository;

@Service
@Transactional(readOnly = true)
public class ClienteServiceImpl implements ClienteService {
    private final ClienteRepository clientes;
    private final ReservaRepository reservas;

    public ClienteServiceImpl(ClienteRepository clientes, ReservaRepository reservas) {
        this.clientes = clientes;
        this.reservas = reservas;
    }

    @Override
    public List<Cliente> listar() {
        return clientes.listarConReservas();
    }

    @Override
    public List<Cliente> buscarPorTexto(String texto) {
        if (texto == null || texto.isBlank()) {
            return clientes.listarConReservas();
        }
        return clientes.buscarConReservas(texto.trim());
    }

    @Override
    public Cliente obligatorio(Long id) {
        return clientes.findById(id)
                .orElseThrow(() -> new NoEncontradoException("No existe el cliente " + id));
    }

    @Override
    public long contar() {
        return clientes.count();
    }

    @Override
    @Transactional
    public Cliente crear(Cliente cliente) {
        cliente.setNombre(cliente.getNombre().trim());
        cliente.setEmail(cliente.getEmail().trim());
        if (clientes.existsByEmail(cliente.getEmail())) {
            throw new ReglaNegocioException("Ya hay un cliente con el email " + cliente.getEmail());
        }

        cliente.setCarnet(new Carnet("G-" + System.currentTimeMillis()));
        return clientes.save(cliente);
    }

    @Override
    @Transactional
    public Cliente actualizar(Long id, Cliente datos) {
        Cliente cliente = obligatorio(id);

        String email = datos.getEmail().trim();

        clientes.findByEmail(email)
                .filter(otro -> !otro.getId().equals(id))
                .ifPresent(otro -> {
                    throw new ReglaNegocioException("Ya hay otro cliente con el email " + email);
                });

        cliente.setNombre(datos.getNombre().trim());
        cliente.setEmail(email);
        return cliente;
    }

    @Override
    @Transactional
    public void borrar(Long id) {
        Cliente cliente = obligatorio(id);

        if (reservas.existsByCliente(cliente)) {
            throw new ReglaNegocioException(
                    "El cliente tiene reservas registradas: no se puede borrar");
        }
        clientes.delete(cliente);
    }

    @Override
    public List<Reserva> obtenerHistorialReservas(Long idCliente) {
        Cliente cliente = obligatorio(idCliente);
        return reservas.historial(cliente);
    }

    @Override
    public int obtenerMaximoReservasPermitidas() {
        return ReservaService.MAXIMO_VIVAS;
    }

    @Override
    public List<ClienteDTO> buscarDTO(String texto) {
        return buscarPorTexto(texto).stream().map(ClienteDTO::de).toList();
    }

    @Override
    public ClienteDTO buscarPorIdDTO(Long id) {
        return ClienteDTO.de(obligatorio(id));
    }

    @Override
    @Transactional
    public ClienteDTO crearDesdeEntrada(ClienteEntrada entrada) {
        Cliente creado = crear(entrada.aCliente());
        return ClienteDTO.de(creado);
    }

    @Override
    @Transactional
    public ClienteDTO actualizarDesdeEntrada(Long id, ClienteEntrada entrada) {
        Cliente actualizado = actualizar(id, entrada.aCliente());
        return ClienteDTO.de(actualizado);
    }
}
