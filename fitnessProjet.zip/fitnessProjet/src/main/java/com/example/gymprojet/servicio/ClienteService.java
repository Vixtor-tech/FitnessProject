package com.example.gymprojet.servicio;

import java.util.List;

import com.example.gymprojet.controlador.dto.ClienteDTO;
import com.example.gymprojet.controlador.dto.ClienteEntrada;
import com.example.gymprojet.modelo.Cliente;
import com.example.gymprojet.modelo.Reserva;

public interface ClienteService {
    List<Cliente> listar();

    List<Cliente> buscarPorTexto(String texto);

    Cliente obligatorio(Long id);

    long contar();

    Cliente crear(Cliente cliente);

    Cliente actualizar(Long id, Cliente datos);

    void borrar(Long id);

    List<Reserva> obtenerHistorialReservas(Long idCliente);

    int obtenerMaximoReservasPermitidas();

    List<ClienteDTO> buscarDTO(String texto);

    ClienteDTO buscarPorIdDTO(Long id);

    ClienteDTO crearDesdeEntrada(ClienteEntrada entrada);

    ClienteDTO actualizarDesdeEntrada(Long id, ClienteEntrada entrada);
}
