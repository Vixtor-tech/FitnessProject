package com.example.gymprojet.config;

import java.time.LocalDate;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.example.gymprojet.modelo.Carnet;
import com.example.gymprojet.modelo.Categoria;
import com.example.gymprojet.modelo.Clase;
import com.example.gymprojet.modelo.Cliente;
import com.example.gymprojet.modelo.Entrenador;
import com.example.gymprojet.modelo.Reserva;
import com.example.gymprojet.repositorio.CategoriaRepository;
import com.example.gymprojet.repositorio.ClaseRepository;
import com.example.gymprojet.repositorio.ClienteRepository;
import com.example.gymprojet.repositorio.EntrenadorRepository;
import com.example.gymprojet.repositorio.ReservaRepository;

@Component
public class DatosIniciales implements CommandLineRunner {
    private final ClaseRepository clases;
    private final CategoriaRepository categorias;
    private final EntrenadorRepository entrenadores;
    private final ClienteRepository clientes;
    private final ReservaRepository reservas;

    public DatosIniciales(ClaseRepository clases, CategoriaRepository categorias,
                          EntrenadorRepository entrenadores, ClienteRepository clientes,
                          ReservaRepository reservas) {
        this.clases = clases;
        this.categorias = categorias;
        this.entrenadores = entrenadores;
        this.clientes = clientes;
        this.reservas = reservas;
    }

    @Override
    @Transactional
    public void run(String... args) {
        if (clases.count() > 0) {
            return;
        }

        Categoria musculacion = categorias.save(new Categoria("Musculación"));
        Categoria cardio = categorias.save(new Categoria("Cardio"));
        Categoria bienestar = categorias.save(new Categoria("Bienestar"));

        Entrenador laura = entrenadores.save(new Entrenador("Laura Gómez"));
        Entrenador pedro = entrenadores.save(new Entrenador("Pedro Ruiz"));
        Entrenador sofia = entrenadores.save(new Entrenador("Sofía Torres"));

        Clase crossfit = nueva("CrossFit", "CF-101", 60, musculacion, pedro);
        nueva("Spinning", "SP-201", 45, cardio, laura);
        nueva("Yoga", "YG-301", 60, bienestar, sofia);
        nueva("Pilates", "PL-302", 50, bienestar, sofia);
        nueva("Zumba", "ZB-202", 55, cardio, laura);
        nueva("Fuerza y pesas", "FP-102", 75, musculacion, pedro);

        Cliente carlos = nuevoCliente("Carlos Pérez", "carlos@gym.com", "G-0001");
        nuevoCliente("María López", "maria@gym.com", "G-0002");
        nuevoCliente("Juan Gómez", "juan@gym.com", "G-0003");

        Reserva vencida = new Reserva(crossfit, carlos);
        vencida.setFechaReserva(LocalDate.now().minusDays(22));
        reservas.save(vencida);
    }

    private Clase nueva(String nombre, String codigo, int minutos, Categoria cat, Entrenador entrenador) {
        Clase c = new Clase(nombre, codigo, minutos);
        c.setCategoria(cat);
        c.getEntrenadores().add(entrenador);
        return clases.save(c);
    }

    private Cliente nuevoCliente(String nombre, String email, String numeroCarnet) {
        Cliente c = new Cliente(nombre, email);
        c.setCarnet(new Carnet(numeroCarnet));
        return clientes.save(c);
    }
}
