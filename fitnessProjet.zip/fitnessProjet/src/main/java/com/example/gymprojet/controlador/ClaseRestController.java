package com.example.gymprojet.controlador;

import java.net.URI;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.gymprojet.controlador.dto.ClaseDTO;
import com.example.gymprojet.controlador.dto.ClaseEntrada;
import com.example.gymprojet.servicio.ClaseService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/clases")
public class ClaseRestController {

    private final ClaseService servicio;

    public ClaseRestController(ClaseService servicio) {
        this.servicio = servicio;
    }

    @GetMapping
    public List<ClaseDTO> listar(@RequestParam(defaultValue = "") String buscar) {
        return servicio.buscarDTO(buscar);
    }

    @GetMapping("/{id}")
    public ClaseDTO una(@PathVariable Long id) {
        return servicio.buscarPorIdDTO(id);
    }

    @PostMapping
    public ResponseEntity<ClaseDTO> crear(@Valid @RequestBody ClaseEntrada entrada) {
        ClaseDTO creada = servicio.crearDesdeEntrada(entrada);
        return ResponseEntity
                .created(URI.create("/api/clases/" + creada.id()))
                .body(creada);
    }

    @PutMapping("/{id}")
    public ClaseDTO editar(@PathVariable Long id, @Valid @RequestBody ClaseEntrada entrada) {
        return servicio.actualizarDesdeEntrada(id, entrada);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void borrar(@PathVariable Long id) {
        servicio.borrar(id);
    }
}
