package com.example.gymprojet.controlador;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.gymprojet.modelo.Clase;
import com.example.gymprojet.servicio.ClaseService;
import com.example.gymprojet.servicio.ReglaNegocioException;

import jakarta.validation.Valid;

@Controller
@RequestMapping("/clases")
public class ClaseController {

    private final ClaseService servicio;

    public ClaseController(ClaseService servicio) {
        this.servicio = servicio;
    }

    @InitBinder("clase")
    void camposDelFormulario(WebDataBinder binder) {
        binder.setAllowedFields("id", "nombre", "codigo", "duracionMinutos", "disponible");
    }

    @GetMapping
    public String catalogo(@RequestParam(defaultValue = "") String buscar, Model modelo) {
        modelo.addAttribute("clases", servicio.buscar(buscar));
        modelo.addAttribute("buscar", buscar);
        return "clases/lista";
    }

    @GetMapping("/nueva")
    public String formularioNueva(Model modelo) {
        modelo.addAttribute("clase", new Clase());
        return "clases/formulario";
    }

    @GetMapping("/{id}")
    public String ficha(@PathVariable Long id, Model modelo) {
        modelo.addAttribute("clase", servicio.obligatoria(id));
        modelo.addAttribute("clientes", servicio.listarClientesParaReserva());
        return "clases/ficha";
    }

    @GetMapping("/{id}/editar")
    public String formularioEditar(@PathVariable Long id, Model modelo) {
        modelo.addAttribute("clase", servicio.obligatoria(id));
        return "clases/formulario";
    }

    @PostMapping
    public String crear(@Valid @ModelAttribute("clase") Clase clase,
                        BindingResult errores,
                        @RequestParam(defaultValue = "") String categoria,
                        @RequestParam(defaultValue = "") String entrenadores,
                        RedirectAttributes flash) {
        if (errores.hasErrors()) {
            return "clases/formulario";
        }
        try {
            servicio.crear(clase, categoria, entrenadores);
            flash.addFlashAttribute("aviso", "Clase añadida");
            return "redirect:/clases";
        } catch (ReglaNegocioException e) {
            errores.reject("regla", e.getMessage());
            return "clases/formulario";
        }
    }

    @PostMapping("/{id}")
    public String editar(@PathVariable Long id,
                         @Valid @ModelAttribute("clase") Clase clase,
                         BindingResult errores,
                         @RequestParam(defaultValue = "") String categoria,
                         @RequestParam(defaultValue = "") String entrenadores,
                         RedirectAttributes flash) {
        if (errores.hasErrors()) {
            return "clases/formulario";
        }
        try {
            servicio.editar(id, clase, categoria, entrenadores);
            flash.addFlashAttribute("aviso", "Cambios guardados");
            return "redirect:/clases/" + id;
        } catch (ReglaNegocioException e) {
            errores.reject("regla", e.getMessage());
            return "clases/formulario";
        }
    }

    @PostMapping("/{id}/borrar")
    public String borrar(@PathVariable Long id, RedirectAttributes flash) {
        try {
            servicio.borrar(id);
            flash.addFlashAttribute("aviso", "Clase borrada");
        } catch (ReglaNegocioException e) {
            flash.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/clases";
    }
}
