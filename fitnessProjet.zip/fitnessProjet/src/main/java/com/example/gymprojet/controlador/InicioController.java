package com.example.gymprojet.controlador;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.gymprojet.controlador.dto.DashboardDTO;
import com.example.gymprojet.servicio.DashboardService;

@Controller
public class InicioController {

    private final DashboardService dashboardService;

    public InicioController(DashboardService dashboardService) {
        this.dashboardService = dashboardService;
    }

    @GetMapping("/")
    public String inicio(Model modelo) {
        DashboardDTO dashboard = dashboardService.obtenerDashboard();
        modelo.addAttribute("totalClases", dashboard.totalClases());
        modelo.addAttribute("totalClientes", dashboard.totalClientes());
        modelo.addAttribute("vencidas", dashboard.vencidas());
        modelo.addAttribute("porCategoria", dashboard.porCategoria());
        modelo.addAttribute("ultimas", dashboard.ultimas());
        return "inicio";
    }
}
