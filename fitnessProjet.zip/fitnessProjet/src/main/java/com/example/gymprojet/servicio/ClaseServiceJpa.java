package com.example.gymprojet.servicio;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.gymprojet.controlador.dto.ClaseDTO;
import com.example.gymprojet.controlador.dto.ClaseEntrada;
import com.example.gymprojet.controlador.dto.ResumenCategoria;
import com.example.gymprojet.modelo.Categoria;
import com.example.gymprojet.modelo.Clase;
import com.example.gymprojet.modelo.Cliente;
import com.example.gymprojet.modelo.Entrenador;
import com.example.gymprojet.repositorio.CategoriaRepository;
import com.example.gymprojet.repositorio.ClaseRepository;
import com.example.gymprojet.repositorio.ClienteRepository;
import com.example.gymprojet.repositorio.EntrenadorRepository;
import com.example.gymprojet.repositorio.ReservaRepository;

@Service
@Transactional(readOnly = true)
public class ClaseServiceJpa implements ClaseService {
    private final ClaseRepository clases;
    private final CategoriaRepository categorias;
    private final EntrenadorRepository entrenadores;
    private final ReservaRepository reservas;
    private final ClienteRepository clientesRepository;

    public ClaseServiceJpa(ClaseRepository clases,
                           CategoriaRepository categorias,
                           EntrenadorRepository entrenadores,
                           ReservaRepository reservas,
                           ClienteRepository clientesRepository) {
        this.clases = clases;
        this.categorias = categorias;
        this.entrenadores = entrenadores;
        this.reservas = reservas;
        this.clientesRepository = clientesRepository;
    }

    @Override
    public List<Clase> listar() {
        return clases.listarConTodo();
    }

    @Override
    public List<Clase> buscar(String texto) {
        if (texto == null || texto.isBlank()) {
            return listar();
        }
        return clases.buscarPorNombreOEntrenador(texto.trim());
    }

    @Override
    public Clase obligatoria(Long id) {
        return clases.findById(id)
                .orElseThrow(() -> new NoEncontradoException("No existe la clase " + id));
    }

    @Override
    public long contar() {
        return clases.count();
    }

    @Override
    public List<Clase> ultimas() {
        return clases.findTop10ByOrderByIdDesc();
    }

    @Override
    public List<ResumenCategoria> resumenPorCategoria() {
        return clases.contarPorCategoria();
    }

    @Override
    @Transactional
    public Clase crear(Clase clase, String categoria, String textoEntrenadores) {
        if (clase.getNombre() != null) {
            clase.setNombre(clase.getNombre().trim());
        }
        if (clase.getCodigo() != null) {
            clase.setCodigo(clase.getCodigo().trim());
        }
        if (clases.existsByCodigo(clase.getCodigo())) {
            throw new ReglaNegocioException("Ya hay una clase con el código " + clase.getCodigo());
        }
        clase.setCategoria(categoriaPorNombre(categoria));
        clase.setEntrenadores(entrenadoresPorNombres(textoEntrenadores));
        return clases.save(clase);
    }

    @Override
    @Transactional
    public Clase editar(Long id, Clase datos, String categoria, String textoEntrenadores) {
        Clase clase = obligatoria(id);

        String codigoNuevo = datos.getCodigo() != null ? datos.getCodigo().trim() : "";
        clases.findByCodigo(codigoNuevo)
              .filter(otra -> !otra.getId().equals(id))
              .ifPresent(otra -> {
                  throw new ReglaNegocioException("Ya hay otra clase con ese código");
              });

        clase.setNombre(datos.getNombre() != null ? datos.getNombre().trim() : "");
        clase.setCodigo(codigoNuevo);
        clase.setDuracionMinutos(datos.getDuracionMinutos());
        clase.setDisponible(datos.isDisponible());
        clase.setCategoria(categoriaPorNombre(categoria));
        clase.setEntrenadores(entrenadoresPorNombres(textoEntrenadores));
        return clase;
    }

    @Override
    @Transactional
    public void borrar(Long id) {
        Clase clase = obligatoria(id);
        if (reservas.existsByClaseAndFechaFinalizacionIsNull(clase)) {
            throw new ReglaNegocioException("No se puede borrar una clase con reservas activas");
        }
        if (reservas.existsByClase(clase)) {
            throw new ReglaNegocioException(
                    "La clase tiene historial de reservas: no se puede borrar");
        }
        clases.delete(clase);
    }

    @Override
    public List<Cliente> listarClientesParaReserva() {
        return clientesRepository.listarConReservas();
    }

    @Override
    public List<ClaseDTO> buscarDTO(String texto) {
        return buscar(texto).stream().map(ClaseDTO::de).toList();
    }

    @Override
    public ClaseDTO buscarPorIdDTO(Long id) {
        return ClaseDTO.de(obligatoria(id));
    }

    @Override
    @Transactional
    public ClaseDTO crearDesdeEntrada(ClaseEntrada entrada) {
        Clase creada = crear(entrada.aClase(), entrada.categoria(), entrada.entrenadores());
        return ClaseDTO.de(creada);
    }

    @Override
    @Transactional
    public ClaseDTO actualizarDesdeEntrada(Long id, ClaseEntrada entrada) {
        Clase actualizada = editar(id, entrada.aClase(), entrada.categoria(), entrada.entrenadores());
        return ClaseDTO.de(actualizada);
    }

    private Categoria categoriaPorNombre(String nombre) {
        if (nombre == null || nombre.isBlank()) {
            return null;
        }
        return categorias.findByNombreIgnoreCase(nombre.trim())
                .orElseGet(() -> categorias.save(new Categoria(nombre.trim())));
    }

    private Set<Entrenador> entrenadoresPorNombres(String texto) {
        if (texto == null || texto.isBlank()) {
            return new HashSet<>();
        }
        return Arrays.stream(texto.split(","))
                .map(String::trim)
                .filter(n -> !n.isEmpty())
                .map(n -> entrenadores.findByNombreIgnoreCase(n)
                                      .orElseGet(() -> entrenadores.save(new Entrenador(n))))
                .collect(Collectors.toSet());
    }
}
