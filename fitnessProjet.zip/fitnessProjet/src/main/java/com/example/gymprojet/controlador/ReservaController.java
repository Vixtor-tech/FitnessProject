package com.example.gymprojet.controlador;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.gymprojet.servicio.ReglaNegocioException;
import com.example.gymprojet.servicio.ReservaService;

@Controller
@RequestMapping("/reservas")
public class ReservaController {
    private final ReservaService servicio;

    public ReservaController(ReservaService servicio) {
        this.servicio = servicio;
    }

    @GetMapping
    public String lista(Model modelo) {
        modelo.addAttribute("vivas", servicio.vivas());
        modelo.addAttribute("vencidas", servicio.vencidas());
        return "reservas/lista";
    }

    @PostMapping("/reservar")
    public String reservar(@RequestParam Long idClase,
                           @RequestParam Long idCliente,
                           RedirectAttributes flash) {
        try {
            servicio.reservar(idClase, idCliente);
            flash.addFlashAttribute("aviso", "Reserva realizada");
        } catch (ReglaNegocioException e) {
            flash.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/clases/" + idClase;
    }

    @PostMapping("/{id}/finalizar")
    public String finalizar(@PathVariable Long id, RedirectAttributes flash) {
        try {
            servicio.finalizar(id);
            flash.addFlashAttribute("aviso", "Reserva finalizada");
        } catch (ReglaNegocioException e) {
            flash.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/reservas";
    }
}
