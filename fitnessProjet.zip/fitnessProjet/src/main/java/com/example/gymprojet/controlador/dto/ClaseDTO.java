package com.example.gymprojet.controlador.dto;

import java.util.List;
import com.example.gymprojet.modelo.Clase;
import com.example.gymprojet.modelo.Entrenador;

public record ClaseDTO(
        Long id,
        String nombre,
        String codigo,
        Integer duracionMinutos,
        boolean disponible,
        String categoria,
        List<String> entrenadores) {
    public static ClaseDTO de(Clase c) {
        return new ClaseDTO(
                c.getId(),
                c.getNombre(),
                c.getCodigo(),
                c.getDuracionMinutos(),
                c.isDisponible(),
                c.getCategoria() == null ? null : c.getCategoria().getNombre(),
                c.getEntrenadores() == null ? List.of() : c.getEntrenadores().stream().map(Entrenador::getNombre).sorted().toList());
    }
}
