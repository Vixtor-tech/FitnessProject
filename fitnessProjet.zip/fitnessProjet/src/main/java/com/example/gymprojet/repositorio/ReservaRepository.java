package com.example.gymprojet.repositorio;

import java.time.LocalDate;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.example.gymprojet.modelo.Clase;
import com.example.gymprojet.modelo.Cliente;
import com.example.gymprojet.modelo.Reserva;

public interface ReservaRepository extends JpaRepository<Reserva, Long> {
    long countByClienteAndFechaFinalizacionIsNull(Cliente cliente);

    boolean existsByClaseAndClienteAndFechaFinalizacionIsNull(Clase clase, Cliente cliente);

    boolean existsByClaseAndFechaFinalizacionIsNull(Clase clase);

    boolean existsByClase(Clase clase);

    boolean existsByCliente(Cliente cliente);

    @Query("""
        select r from Reserva r
        join fetch r.clase
        where r.cliente = :cliente
        order by r.fechaReserva desc
    """)
    List<Reserva> historial(@Param("cliente") Cliente cliente);

    @Query("""
        select r from Reserva r
        join fetch r.clase
        join fetch r.cliente
        where r.fechaFinalizacion is null
        order by r.fechaReserva
    """)
    List<Reserva> vivas();

    @Query("""
        select r from Reserva r
        join fetch r.clase
        join fetch r.cliente
        where r.fechaFinalizacion is null and r.fechaReserva < :limite
        order by r.fechaReserva
    """)
    List<Reserva> vencidas(@Param("limite") LocalDate limite);
}
