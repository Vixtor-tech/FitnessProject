package com.example.gymprojet.servicio;

import java.util.List;

import com.example.gymprojet.controlador.dto.ClaseDTO;
import com.example.gymprojet.controlador.dto.ClaseEntrada;
import com.example.gymprojet.controlador.dto.ResumenCategoria;
import com.example.gymprojet.modelo.Clase;
import com.example.gymprojet.modelo.Cliente;

public interface ClaseService {
    List<Clase> listar();

    List<Clase> buscar(String texto);

    Clase obligatoria(Long id);

    long contar();

    List<Clase> ultimas();

    List<ResumenCategoria> resumenPorCategoria();

    Clase crear(Clase clase, String categoria, String entrenadores);

    Clase editar(Long id, Clase datos, String categoria, String entrenadores);

    void borrar(Long id);

    List<Cliente> listarClientesParaReserva();

    List<ClaseDTO> buscarDTO(String texto);

    ClaseDTO buscarPorIdDTO(Long id);

    ClaseDTO crearDesdeEntrada(ClaseEntrada entrada);

    ClaseDTO actualizarDesdeEntrada(Long id, ClaseEntrada entrada);
}
