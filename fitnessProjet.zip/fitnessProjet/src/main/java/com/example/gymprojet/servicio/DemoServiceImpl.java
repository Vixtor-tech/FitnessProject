package com.example.gymprojet.servicio;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class DemoServiceImpl implements DemoService {

    private static final List<String> CLIENTES_DEMO = List.of(
            "Carlos Pérez - Musculación",
            "María López - Cardio",
            "Juan Gómez - Piernas",
            "Laura Torres - Yoga",
            "Ana Martínez - Glúteos"
    );

    @Override
    public String generarSaludo(String nombre) {
        String nombreFinal = (nombre == null || nombre.isBlank()) ? "Deportista" : nombre.trim();
        return String.format("¡Hola, %s! Bienvenido a fitnessProjet.", nombreFinal);
    }

    @Override
    public String calcularCuota(String membresia) {
        return "Cuota calculada para la membresía: " + (membresia != null ? membresia.trim() : "");
    }

    @Override
    public String filtrarOListar(String q) {
        if (q == null || q.isBlank()) {
            return "Mostrando todos los clientes del gimnasio";
        }
        return "Filtrando clientes por: " + q.trim();
    }

    @Override
    public String generarRutina(String ejercicio, int series) {
        int repeticiones = Math.max(1, series);
        String nombreEjercicio = (ejercicio != null) ? ejercicio.trim() : "General";
        return ("Ejercicio: " + nombreEjercicio + ". ").repeat(repeticiones).trim();
    }

    @Override
    public List<String> obtenerClientesDemo() {
        return CLIENTES_DEMO;
    }

    @Override
    public String obtenerClienteDemoPorIndice(int indice) {
        if (indice < 0 || indice >= CLIENTES_DEMO.size()) {
            throw new IndexOutOfBoundsException("Índice de cliente demo fuera de rango: " + indice);
        }
        return CLIENTES_DEMO.get(indice);
    }
}
