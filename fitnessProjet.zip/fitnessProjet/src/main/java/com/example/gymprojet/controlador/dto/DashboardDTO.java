package com.example.gymprojet.controlador.dto;

import java.util.List;

import com.example.gymprojet.modelo.Clase;

public record DashboardDTO(
        long totalClases,
        long totalClientes,
        int vencidas,
        List<ResumenCategoria> porCategoria,
        List<Clase> ultimas
) {}
