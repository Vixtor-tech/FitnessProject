package com.example.gymprojet.controlador;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.gymprojet.modelo.Cliente;
import com.example.gymprojet.servicio.ClienteService;
import com.example.gymprojet.servicio.ReglaNegocioException;

import jakarta.validation.Valid;

@Controller
@RequestMapping("/clientes")
public class ClienteController {

    private final ClienteService servicio;

    public ClienteController(ClienteService servicio) {
        this.servicio = servicio;
    }

    @InitBinder("cliente")
    void camposDelFormulario(WebDataBinder binder) {
        binder.setAllowedFields("id", "nombre", "email");
    }

    @GetMapping
    public String listar(@RequestParam(defaultValue = "") String buscar, Model model) {
        model.addAttribute("clientes", servicio.buscarPorTexto(buscar));
        model.addAttribute("buscar", buscar);
        model.addAttribute("maximo", servicio.obtenerMaximoReservasPermitidas());
        return "clientes/lista";
    }

    @GetMapping("/nuevo")
    public String nuevoFormulario(Model model) {
        model.addAttribute("cliente", new Cliente());
        return "clientes/formulario";
    }

    @GetMapping("/{id}")
    public String ver(@PathVariable Long id, Model model) {
        model.addAttribute("cliente", servicio.obligatorio(id));
        model.addAttribute("reservas", servicio.obtenerHistorialReservas(id));
        return "clientes/detalle";
    }

    @GetMapping("/{id}/editar")
    public String editarFormulario(@PathVariable Long id, Model model) {
        model.addAttribute("cliente", servicio.obligatorio(id));
        return "clientes/formulario";
    }

    @PostMapping
    public String guardar(@Valid @ModelAttribute("cliente") Cliente cliente,
                          BindingResult errores,
                          RedirectAttributes flash) {
        if (errores.hasErrors()) {
            return "clientes/formulario";
        }
        try {
            servicio.crear(cliente);
            flash.addFlashAttribute("aviso", "Cliente registrado");
            return "redirect:/clientes";
        } catch (ReglaNegocioException e) {
            errores.rejectValue("email", "duplicado", e.getMessage());
            return "clientes/formulario";
        }
    }

    @PostMapping("/{id}")
    public String actualizar(@PathVariable Long id,
                             @Valid @ModelAttribute("cliente") Cliente cliente,
                             BindingResult errores,
                             RedirectAttributes flash) {
        if (errores.hasErrors()) {
            return "clientes/formulario";
        }
        try {
            servicio.actualizar(id, cliente);
            flash.addFlashAttribute("aviso", "Cambios guardados");
            return "redirect:/clientes/" + id;
        } catch (ReglaNegocioException e) {
            errores.rejectValue("email", "duplicado", e.getMessage());
            return "clientes/formulario";
        }
    }

    @PostMapping("/{id}/borrar")
    public String borrar(@PathVariable Long id, RedirectAttributes flash) {
        try {
            servicio.borrar(id);
            flash.addFlashAttribute("aviso", "Cliente borrado");
        } catch (ReglaNegocioException e) {
            flash.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/clientes";
    }
}
