package com.example.gymprojet.repositorio;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.gymprojet.modelo.Entrenador;

public interface EntrenadorRepository extends JpaRepository<Entrenador, Long> {
    Optional<Entrenador> findByNombreIgnoreCase(String nombre);
}
