package com.example.gymprojet.modelo;

import java.util.HashSet;
import java.util.Set;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
@Table(name = "clases")
public class Clase {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "El nombre es obligatorio")
    @Column(nullable = false, length = 200)
    private String nombre;

    @NotBlank(message = "El código es obligatorio")
    @Pattern(regexp = "[A-Za-z0-9\\-]{3,20}", message = "El código debe tener 3-20 letras, números o guiones")
    @Column(nullable = false, unique = true, length = 20)
    private String codigo;

    @NotNull(message = "La duración es obligatoria")
    @Min(value = 15, message = "La duración mínima es de 15 minutos")
    @Max(value = 300, message = "La duración no puede superar los 300 minutos")
    @Column(name = "duracion_minutos")
    private Integer duracionMinutos;

    @Column(nullable = false)
    private boolean disponible = true;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "categoria_id")
    private Categoria categoria;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "clases_entrenadores",
            joinColumns = @JoinColumn(name = "clase_id"),
            inverseJoinColumns = @JoinColumn(name = "entrenador_id"))
    private Set<Entrenador> entrenadores = new HashSet<>();

    public Clase() {
    }

    public Clase(String nombre, String codigo, Integer duracionMinutos) {
        this.nombre = nombre;
        this.codigo = codigo;
        this.duracionMinutos = duracionMinutos;
    }

    public String getNombresEntrenadores() {
        if (entrenadores == null || entrenadores.isEmpty()) {
            return "";
        }
        return String.join(", ", entrenadores.stream().map(Entrenador::getNombre).sorted().toList());
    }

    public String getEntrenadoresComoTexto() {
        if (entrenadores == null || entrenadores.isEmpty()) {
            return "Sin entrenador";
        }
        return getNombresEntrenadores();
    }

    public String getNombreCategoria() {
        return categoria == null ? "" : (categoria.getNombre() == null ? "" : categoria.getNombre());
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public Integer getDuracionMinutos() {
        return duracionMinutos;
    }

    public void setDuracionMinutos(Integer duracionMinutos) {
        this.duracionMinutos = duracionMinutos;
    }

    public boolean isDisponible() {
        return disponible;
    }

    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    public Set<Entrenador> getEntrenadores() {
        return entrenadores;
    }

    public void setEntrenadores(Set<Entrenador> entrenadores) {
        this.entrenadores = entrenadores;
    }
}
