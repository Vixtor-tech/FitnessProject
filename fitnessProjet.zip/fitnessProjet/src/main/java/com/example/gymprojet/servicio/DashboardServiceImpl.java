package com.example.gymprojet.servicio;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.gymprojet.controlador.dto.DashboardDTO;

@Service
@Transactional(readOnly = true)
public class DashboardServiceImpl implements DashboardService {

    private final ClaseService clases;
    private final ClienteService clientes;
    private final ReservaService reservas;

    public DashboardServiceImpl(ClaseService clases, ClienteService clientes, ReservaService reservas) {
        this.clases = clases;
        this.clientes = clientes;
        this.reservas = reservas;
    }

    @Override
    public DashboardDTO obtenerDashboard() {
        return new DashboardDTO(
                clases.contar(),
                clientes.contar(),
                reservas.contarVencidas(),
                clases.resumenPorCategoria(),
                clases.ultimas()
        );
    }
}
